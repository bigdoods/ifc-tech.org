//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by miniExample.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MINIEXAMPLE_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_EDIT_FILE_NAME              1000
#define IDC_EDIT_SCHEMA_NAME            1001
#define IDC_EDIT_WALL_THICKNESS         1007
#define IDC_EDIT_WALL_HEIGHT            1008
#define IDC_EDIT_WALL_WIDTH             1009
#define IDC_EDIT_FLOOR_THICKNESS        1010
#define IDC_EDIT_OPENING_X_OFFSET       1010
#define IDC_STATIC_00                   1011
#define IDC_STATIC_10                   1012
#define IDC_STATIC_20                   1013
#define IDC_STATIC_30                   1014
#define IDC_STATIC_01                   1015
#define IDC_STATIC_11                   1016
#define IDC_STATIC_21                   1017
#define IDC_STATIC_31                   1018
#define IDC_EDIT_OPENING_Y_OFFSET       1019
#define IDC_STATIC_40                   1020
#define IDC_CHECK_OPENING               1021
#define IDC_CHECK_WINDOW                1022
#define IDC_CHECK_WALL                  1023
#define IDC_RADIO_0_0                   1024
#define IDC_RADIO_0_1                   1025
#define IDC_RADIO_0_2                   1026
#define IDC_RADIO_1_0                   1027
#define IDC_RADIO_1_1                   1028
#define IDC_RADIO_1_2                   1029
#define IDC_RADIO_2_0                   1030
#define IDC_RADIO_2_1                   1031
#define IDC_RADIO_2_2                   1032
#define IDC_CHECK_WALL_BASICREPR        1033
#define IDC_CHECK_OPENING_BASICREPR     1034
#define IDC_CHECK_WINDOW_BASICREPR      1035
#define IDC_STATIC_0_0                  1036
#define IDC_STATIC_0_1                  1037
#define IDC_STATIC_1_0                  1038
#define IDC_STATIC_1_1                  1039
#define IDC_STATIC_2_0                  1040
#define IDC_STATIC_2_1                  1041
#define IDC_STATIC_41                   1042
#define IDC_EDIT_OPENING_HEIGHT         1043
#define IDC_STATIC_50                   1044
#define IDC_STATIC_51                   1045
#define IDC_EDIT_OPENING_WIDTH          1046
#define IDC_STATIC_60                   1047
#define IDC_STATIC_61                   1048
#define IDC_EDIT_WINDOW_THICKNESS       1049
#define IDC_STATIC_70                   1050
#define IDC_STATIC_71                   1051
#define IDC_EDIT_WINDOW_HEIGHT          1052
#define IDC_STATIC_80                   1053
#define IDC_STATIC_81                   1054
#define IDC_EDIT_0_NAME                 1055
#define IDC_STATIC_0_NAME               1056
#define IDC_EDIT_1_NAME                 1057
#define IDC_STATIC_1_NAME               1058
#define IDC_EDIT_2_NAME                 1059
#define IDC_STATIC_2_NAME               1060
#define IDC_IFX                         1061
#define IDC_RADIO_VIEW_0                1062
#define IDC_RADIO_VIEW_1                1063
#define IDC_IFC                         1064
#define IDC_CHECK_QUANTITIES            1066
#define IDC_CHECK_METERS                1067

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1068
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
