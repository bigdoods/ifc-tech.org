// RandomUuid.h
// ----------------------------------------------------------------------------
// provided "as-is", no warranty, no support is given to the users of this code
// ----------------------------------------------------------------------------
// Public include file for the uuid_generate_random functionality in c++11
// (
//   Produces valid random UUID's according to standard:
//    http://www.itu.int/rec/T-REC-X.667-201210-I/en
//    http://tools.ietf.org/html/rfc4122
// )
//
// Copyright (C) 2015 Janos Maros.
//
// Redistribution and use with or without modification, are permitted
//

#ifndef RANDOM_UUID_H
#define RANDOM_UUID_H

#include <cstdint>
#include <algorithm>
#include <chrono>
#include <numeric>
#include <random>

namespace randuid {

	using  uuid_t=uint8_t[16];

	class RandUI32 {
		using hrc = std::chrono::high_resolution_clock;
		std::mt19937	re;
	public:
		RandUI32 ()
			:	re(static_cast<uint32_t>(hrc::now().time_since_epoch().count()))
		{
		}

		uint32_t operator() ()
		{
			return re();
		}
	};

//#if defined FixUUID
//	inline void RandomUuid(uuid_t out)
//	{
//		//Setting the value of octet's to their zero based indices:
//		std::iota(&out[0],
//				  &out[16],
//				  0);
//		//Setting the octet number:
//		std::for_each(&out[0],
//					  &out[16],
//					  [](uint8_t& v){v = 15 - v;});
//	}
//#else
	inline void RandomUuid(uuid_t out)
	{
		RandUI32 rand32;

		union ConvInOut {
			uint8_t		o[16];
			uint32_t	i[4];		
		}c;

		c.i[0] = rand32();
		c.i[1] = rand32();
		c.i[2] = rand32();
		c.i[3] = rand32();
	
		c.o[6] &= 0x0F;	// Version specified in T-REC-X.667-201210-I/en
		c.o[6] |= 0x40;	// to the random-number-based version in octet 9.
	
		c.o[8] &= 0x3F;	// Variant specified in T-REC-X.667-201210-I/en
		c.o[8] |= 0x80;	// to rfc4122 International Standard in octet 7.

		std::copy(&c.o[0], &c.o[16], &out[0]);
	}
//#endif
	// uuid function wrappers
	inline int uuid_generate_time_safe (uuid_t)     { return -1; }
	inline void uuid_generate_random   (uuid_t out) { RandomUuid(out); }
}

#endif /* RANDOM_UUID_H */
