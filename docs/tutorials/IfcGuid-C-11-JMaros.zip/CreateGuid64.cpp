// CreateGuid64.cpp
// ----------------------------------------------------------------------------
// provided "as-is", no warranty, no support is given to the users of this code
// ----------------------------------------------------------------------------
//
// Creating of a GUID string using the CoCreateGuid function from Microsoft
// as originally proposed by Jim Forester
// implemented previously by Jeremy Tammik using hex-encoding and by
// Peter Muigg, June 1998 for the mapping of the base 85 strings (20 chars).
// The obsolete base 85 string functions were  removed in 2015.
// The code upgraded to use c++11, and standard template library.
//
// This version uses a number system with base 64 to obtain a string with 22 characters.
//
// Janos Maros, July  2000
// Janos Maros, March 2015
//
// How to compile on different platforms:
//
// Linux, using:
//
// GCC 4.9.2 or above:
// g++ -std=c++11 -Wall -Werror -Wundef --pedantic -O2 CreateGuid64.cpp IfcGuidTest.cpp -o IfcGuidTest && ./IfcGuidTest
// g++ -std=c++11 -DRandomUUID -Wall -Werror -Wundef --pedantic CreateGuid64.cpp IfcGuidTest.cpp -o IfcGuidTest && ./IfcGuidTest
//
// Windows, using:
//
// STL-MinGW (Stephan T. Lavavej's MinGW distribution - http://nuwen.net):
// g++ -std=c++11 -Dlinux -DRandomUUID -Wall -Werror -Wundef --pedantic -O2 CreateGuid64.cpp IfcGuidTest.cpp -o IfcGuidTest && IfcGuidTest
// and for debugging:
// g++ -std=c++11 -Dlinux -DRandomUUID -Wall -Werror -Wundef --pedantic -g -O0 CreateGuid64.cpp IfcGuidTest.cpp -o IfcGuidTest && gdb IfcGuidTest
//
// DevCmd (VS2013 or above):
// cl  /EHsc /Zc:forScope,wchar_t,auto,rvalueCast,strictStrings /W4 /WX IfcGuidTest.cpp CreateGuid64.cpp  "ole32.lib"  && IfcGuidTest
// cl  /Dlinux /DRandomUUID /EHa /Zc:forScope,wchar_t,auto,rvalueCast,strictStrings /W4 /WX IfcGuidTest.cpp CreateGuid64.cpp  && IfcGuidTest
//

#if		defined __unix__ || \
		defined   linux

#if defined RandomUUID
#include	"RandomUuid.h"
using namespace randuid;
#else
#include	<uuid/uuid.h>
#endif

#elif	defined _WIN32	||	\
		defined  WIN32	||	\
		defined _WIN64	||	\
		defined  WIN64

#include    <Windows.h>
#endif

#include    <iomanip>
#include    <ios>
#include    <map>
#include	<regex> 
#include    <string>
#include    <sstream>

#include    <cstdint>

#include    "CreateGuid64.h"

using namespace std;
//
// For non windows platforms you probably will need
// the following definitions instead of <Windows.h>
// to use this module:
//
#if		defined __unix__	||	\
		defined   linux


typedef struct _GUID {
    uint32_t	Data1;
    uint16_t	Data2;
    uint16_t	Data3;
    uint8_t		Data4[8];
} GUID;

const GUID GUID_NULL {0, 0, 0, {0, 0, 0, 0, 0, 0, 0, 0}};

inline bool operator == (const  GUID	&a,
						 const  GUID	&b)
{
	return (a.Data1		==	b.Data1		&&
			a.Data2		==	b.Data2		&&
			a.Data3		==	b.Data3		&&
			a.Data4[0]	==	b.Data4[0]	&&
			a.Data4[1]	==	b.Data4[1]	&&
			a.Data4[2]	==	b.Data4[2]	&&
			a.Data4[3]	==	b.Data4[3]	&&
			a.Data4[4]	==	b.Data4[4]	&&
			a.Data4[5]	==	b.Data4[5]	&&
			a.Data4[6]	==	b.Data4[6]	&&
			a.Data4[7]	==	b.Data4[7]);
}
inline bool operator != (const  GUID	&a,
						 const  GUID	&b)
{
	return !(a == b);
}

static void Uuid2Guid (const uuid_t	&in,
					   GUID			*pGuid)
{
	// Is sizeof uint32_t == 2 * sizeof uint16_t == 4 * sizeof uint8_t?
	static_assert(((sizeof(uint32_t)) == (sizeof(uint16_t)) * 2), "Size 1.");
	static_assert(((sizeof(uint16_t)) == (sizeof(uint8_t)) * 2), "Size 2.");
	static_assert(sizeof(uint8_t) == 1, "Size 3.");

	union ConvU16 {
		uint16_t	u16;
		uint8_t		u8[2];
	} convU16;

	union ConvU32 {
		uint32_t	u32;
		uint16_t	u16[2];
	} convU32;

	convU16.u16 = 1;
	convU32.u32 = 1;

	if (pGuid) {
		ConvU32 c32;
		ConvU16 c16;
		c16.u8[convU16.u8[0]] = in[0];
		c16.u8[convU16.u8[1]] = in[1];
		c32.u16[convU32.u16[0]] = c16.u16;
		c16.u8[convU16.u8[0]] = in[2];
		c16.u8[convU16.u8[1]] = in[3];
		c32.u16[convU32.u16[1]] = c16.u16;
		pGuid->Data1 = c32.u32;
		c16.u8[convU16.u8[0]] = in[4];
		c16.u8[convU16.u8[1]] = in[5];
		pGuid->Data2 = c16.u16;
		c16.u8[convU16.u8[0]] = in[6];
		c16.u8[convU16.u8[1]] = in[7];
		pGuid->Data3 = c16.u16;
		for (int i = 0; i < 8; ++i) {
			pGuid->Data4[i] = in[i + 8];
		}
	}
}

static long CoCreateGuid(GUID   *pGuid)
{
	uuid_t out;
	if (uuid_generate_time_safe(out) != 0) {
		uuid_generate_random(out);
	}
	Uuid2Guid(out, pGuid);
	return 0;
}

#endif
//
// .net: ReplyGuid = System.Guid.NewGuid().ToString();
//
namespace CreateGuidImplementation {
	static string GetString16FromGuid(const GUID &	guid);
	static string GetString64FromGuid(const GUID &	guid);

	static bool GetGuidFromHexGuidStr (const string	&	str16,
									   GUID			*	pGuid);

	static bool GetGuidFromIcfGuid(const string	&	icfGuid,
								   GUID			*	pGuid);

	static bool CvTo64(const uint32_t	number,
					   string &			code,
					   int				nDigits);

	static bool CvFrom64(uint32_t *		pRes,
						 const string	str);

	// Conversion Table must start with "0", this is the digit for the additive unit
	static const char * 	ConversionTable ()
	{
		static const char *		conversionTable = {
			//          1         2         3         4         5         6   
			//0123456789012345678901234567890123456789012345678901234567890123
			 "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$"
		};
		return conversionTable;
	}

	static const map<char, int> &	ConversionMap ()
	{
		static map<char, int> cm;
		if (cm.size() == 0) {
			// init the conversion map on it's first use;
			for (int i = 0; i < 64; ++i) {
				cm[ConversionTable()[i]]= i;
			}
		}
		return cm;
	}


	//
	// Conversion of a GUID to a string representing the GUID, the string
	// will hold 38 characters + 1 for the terminating 0
	// (6 extra characters for the separation)
	//
	static string GetString16FromGuid (const GUID &		guid)
	{
		stringstream s16;
		s16 << hex << right << setfill('0');
		s16 << "{" << setw(8) << guid.Data1;			//"%08X"
		s16 << "-" << setw(4) << guid.Data2;			//"%04X"
		s16 << "-" << setw(4) << guid.Data3;			//"%04X"
		s16 << "-" << setw(2) << int(guid.Data4[0]);	//"%02X"
		s16		   << setw(2) << int(guid.Data4[1]);	//"%02X"
		s16 << "-" << setw(2) << int(guid.Data4[2]);	//"%02X"
		s16		   << setw(2) << int(guid.Data4[3]);	//"%02X"
		s16		   << setw(2) << int(guid.Data4[4]);	//"%02X"
		s16		   << setw(2) << int(guid.Data4[5]);	//"%02X"
		s16		   << setw(2) << int(guid.Data4[6]);	//"%02X"
		s16		   << setw(2) << int(guid.Data4[7]);	//"%02X"
		s16	<< "}";
		return s16.str();
	}

	//
	// Conversion of a GUID to a string representing the GUID, the buffer must be able
	// to hold 22 characters + 1 for the terminating 0
	//
	static string GetString64FromGuid(const GUID &	guid)
	{
		uint32_t	num[6];

		//
		// Creation of six 32 Bit integers from the components of the GUID structure
		//
		num[0] = (uint32_t) (guid.Data1 / 16777216);                                            //    16. byte  (guid.Data1 / 16777216) is the same as (guid.Data1 >> 24)
		num[1] = (uint32_t) (guid.Data1 % 16777216);                                            // 15-13. bytes (guid.Data1 % 16777216) is the same as (guid.Data1 & 0xFFFFFF)
		num[2] = (uint32_t) (guid.Data2 * 256 + guid.Data3 / 256);                              // 12-10. bytes
		num[3] = (uint32_t) ((guid.Data3 % 256) * 65536 + guid.Data4[0] * 256 + guid.Data4[1]); // 09-07. bytes
		num[4] = (uint32_t) (guid.Data4[2] * 65536 + guid.Data4[3] * 256 + guid.Data4[4]);      // 06-04. bytes
		num[5] = (uint32_t) (guid.Data4[5] * 65536 + guid.Data4[6] * 256 + guid.Data4[7]);      // 03-01. bytes
		//
		// Conversion of the numbers into a system using a base of 64
		//
		stringstream s22;
		string		str[6];
		for (int i = 0, n = 2; i < 6; i++, n = 4) {
			if (!CvTo64(num[i], str[i], n)) {
				//error in conversion, empty the string
				s22.clear();
				break;
			}
			s22 << str[i];
		}
		return s22.str();
	}

	//
	// Conversion of a GUID to a string representing the GUID, the string
	// will hold 38 characters + 1 for the terminating 0
	// (6 extra characters for the separation)
	//
	static bool GetGuidFromHexGuidStr (const string	&	str16,
									   GUID	*			pGuid)
	{
		bool success = false;
		if (pGuid) {
			stringstream s16 (str16);
			char ch = 0;
			s16 >> hex;
			s16 >> ch;
			if (ch == '{') {
				s16 >> pGuid->Data1 >> ch;
			} else {
				ch = 0;
			}
			if (ch == '-') {
				s16 >> pGuid->Data2 >> ch;
			} else {
				ch = 0;
			}
			if (ch == '-') {
				s16 >> pGuid->Data3 >> ch;
			} else {
				ch = 0;
			}
			if (ch == '-') {
				uint16_t twoBytes = 0;
				s16 >> twoBytes >> ch;
				pGuid->Data4[0] = (twoBytes >>  8) & UINT8_MAX;
				pGuid->Data4[1] = (twoBytes      ) & UINT8_MAX;
			} else {
				ch = 0;
			}
			if (ch == '-') {
				uint64_t eightBytes = 0;
				s16 >> eightBytes >> ch;
				pGuid->Data4[2] = (eightBytes >> 40) & UINT8_MAX;
				pGuid->Data4[3] = (eightBytes >> 32) & UINT8_MAX;
				pGuid->Data4[4] = (eightBytes >> 24) & UINT8_MAX;
				pGuid->Data4[5] = (eightBytes >> 16) & UINT8_MAX;
				pGuid->Data4[6] = (eightBytes >>  8) & UINT8_MAX;
				pGuid->Data4[7] = (eightBytes      ) & UINT8_MAX;
			} else {
				ch = 0;
			}
			if (ch == '}') {
				success = true;
			}
			if (!success) {
				*pGuid	= GUID_NULL;
			}
		}
		return success;
	}

	//
	// Reconstruction of the GUID structure from the coded string
	//
	static bool GetGuidFromIcfGuid (const string &	icfGuid,
									 GUID *			pGuid)
	{
		if (icfGuid.length() != 22) {
			return false;
		}
		string str[6];
		for (int i = 0, j = 0, m = 2; i < 6; ++i, m = 4) {
			str[i] = icfGuid.substr(j, m);
			j += m;
		}
		uint32_t	num[6] = {0};
		for (int i = 0; i < 6; ++i) {
			if (!CvFrom64(&num[i], str[i])) {
				return false;
			}
		}
		pGuid->Data1= (uint32_t) (num[0] * 16777216 + num[1]);                // 16-13. bytes
		pGuid->Data2= (uint16_t) (num[2] / 256);                              // 12-11. bytes
		pGuid->Data3= (uint16_t) ((num[2] % 256) * 256 + num[3] / 65536);     // 10-09. bytes
		pGuid->Data4[0] = (uint8_t) ((num[3] / 256) % 256);                   //    08. byte
		pGuid->Data4[1] = (uint8_t) (num[3] % 256);                           //    07. byte
		pGuid->Data4[2] = (uint8_t) (num[4] / 65536);                         //    06. byte
		pGuid->Data4[3] = (uint8_t) ((num[4] / 256) % 256);                   //    05. byte
		pGuid->Data4[4] = (uint8_t) (num[4] % 256);                           //    04. byte
		pGuid->Data4[5] = (uint8_t) (num[5] / 65536);                         //    03. byte
		pGuid->Data4[6] = (uint8_t) ((num[5] / 256) % 256);                   //    02. byte
		pGuid->Data4[7] = (uint8_t) (num[5] % 256);                           //    01. byte
		return true;
	}

	//
	// Conversion of a 32 bit unsigned integer into code with base 64
	//
	static bool CvTo64 (const uint32_t		number,
						string &			code,
						int					nDigits)
	{
		uint32_t	act = number;

		if (0 < nDigits && nDigits < 5) {

			char result[5] = {0};

			for (int iDigit = 0; iDigit < nDigits; iDigit++) {
				result[nDigits - 1 - iDigit] = 
					ConversionTable()[static_cast<int>(act % 64)];
				act /= 64;
			}
			result[nDigits] = '\0'; 
	   
			if (act == 0) {
				code = result;
			}
		} else {
			act = 1;
		}
		return (act == 0);
	}

	//
	// The reverse function to calculate the number from the code
	//
	static bool CvFrom64 (uint32_t *	pRes,
						  const string	str)
	{
		bool 	 bResult = false;
		uint32_t res = 0;
		bResult = (str.length() > 0 && str.length() <= 4);
		for (size_t i = 0; bResult && i < str.length(); ++i) {
			auto it = ConversionMap().find(str[i]);
			bResult = (it != ConversionMap().end());
			if (bResult) {
				res = res * 64 + it->second;
			}
		}
		if (bResult && pRes != nullptr) {
			*pRes = res;
		}
		return bResult;
	}
}
using namespace CreateGuidImplementation;
//
// Creation of the string representing the GUID, the buffer must be able
// to hold 22 characters + 1 for the terminating 0
//
IfcGuid::IfcGuid ()
	:	m_ifcGuid ()
{
	GUID	guid = GUID_NULL;

	// Call to the function from Microsoft
    CoCreateGuid (&guid);
    if (guid != GUID_NULL) {
        m_ifcGuid = GetString64FromGuid (guid);
    }
}

IfcGuid::IfcGuid (const IfcGuid &	ig)
	:	m_ifcGuid (ig.m_ifcGuid)
{
}

IfcGuid::IfcGuid (IfcGuid&&  ig)
	:	m_ifcGuid (ig.m_ifcGuid)
{
}

IfcGuid::IfcGuid (const string &	guidStr,
				  Base			 	base/* = Base16*/)
	:	m_ifcGuid ()
{
    GUID	guid;
	switch (base) {
		case Base16:
			if (GetGuidFromHexGuidStr (guidStr, &guid)) {
				m_ifcGuid = GetString64FromGuid (guid);
			}
			break;
		case Base64: {
				// Check if it looks like an IfcGuid, or not.
				regex rx("^[0-9a-zA-Z_$]{22,22}$");
				cmatch mr;
				if (regex_search(guidStr.c_str(), mr, rx)) {
					if (mr[0].length() == 22) {
						m_ifcGuid = guidStr;
					}
				}
			}
			break;
		default:
			// illegal, empty string returned.
			break;
	}
}

// In this case there is no need to check against self assignment.
IfcGuid& IfcGuid::operator= (const IfcGuid& rig)
{
	m_ifcGuid = rig.m_ifcGuid;
	return *this;
}

IfcGuid& IfcGuid::operator= (IfcGuid&& rva)
{
	m_ifcGuid = move(rva.m_ifcGuid);
	return *this;
}

//
// These routines will return an empty string on failure.
//

const string& IfcGuid::operator()() const
{
	return m_ifcGuid;
}

const string IfcGuid::B64() const
{
	return  m_ifcGuid;
}

const string IfcGuid::B16() const
{
	string	hexGuid;
    GUID	guid;
    if (GetGuidFromIcfGuid (m_ifcGuid, &guid)) {
        hexGuid = GetString16FromGuid (guid);
    }
    return hexGuid;
}

const string IfcGuid::Get(Base base) const
{
	string guis;
	switch (base) {
		case Base16:
			guis = B16();
			break;
		case Base64:
			guis = B64();
			break;
		default:
			// illegal, empty string returned.
			break;
	}
	return guis;
}

//
// Mapping the base 64 string to the conventional GUID string.
//
string IfcGuid::ToHex (const IfcGuid	&ifcGuid)
{
    return ifcGuid.B16();
}

IfcGuid IfcGuid::FromHex (const string	&hexGuid)
{
	return IfcGuid(hexGuid, Base16);
}
