// IfcGuidTest.cpp : Defines the entry point for the test console application.
// ----------------------------------------------------------------------------
// provided "as-is", no warranty, no support is given to the users of this code
// ----------------------------------------------------------------------------
// Copyright (C) 2015 Janos Maros.
//
// Redistribution and use with or without modification, are permitted
//
//
// How to compile on different platforms:
//
// Linux, using:
//
// GCC 4.9.2 or above:
// g++ -std=c++11 -Wall -Werror -Wundef --pedantic -O2 CreateGuid64.cpp IfcGuidTest.cpp -o IfcGuidTest && ./IfcGuidTest
// g++ -std=c++11 -DRandomUUID -Wall -Werror -Wundef --pedantic CreateGuid64.cpp IfcGuidTest.cpp -o IfcGuidTest && ./IfcGuidTest
//
// Windows, using:
//
// STL-MinGW (Stephan T. Lavavej's MinGW distribution - http://nuwen.net):
// g++ -std=c++11 -Dlinux -DRandomUUID -Wall -Werror -Wundef --pedantic -O2 CreateGuid64.cpp IfcGuidTest.cpp -o IfcGuidTest && IfcGuidTest
// and for debugging:
// g++ -std=c++11 -Dlinux -DRandomUUID -Wall -Werror -Wundef --pedantic -g -O0 CreateGuid64.cpp IfcGuidTest.cpp -o IfcGuidTest && gdb IfcGuidTest
//
// DevCmd (VS2013 or above):
// cl  /EHsc /Zc:forScope,wchar_t,auto,rvalueCast,strictStrings /W4 /WX IfcGuidTest.cpp CreateGuid64.cpp  "ole32.lib"  && IfcGuidTest
// cl  /Dlinux /DRandomUUID /EHa /Zc:forScope,wchar_t,auto,rvalueCast,strictStrings /W4 /WX IfcGuidTest.cpp CreateGuid64.cpp  && IfcGuidTest
//

#include "CreateGuid64.h"
#include <iostream>

using namespace std;

int main ()
{
	string quom {"\""};
	string ifcGuids[] {
		"0000000000000000000000",
		"0F3WqC2me920S61GG30W40"
	};
	string eq {quom + " <--> " + quom};
	for(auto ifcGuid : ifcGuids) {
		cout << quom << ifcGuid << eq;
		cout << IfcGuid::ToHex(IfcGuid(ifcGuid));
		cout << quom << endl;
	}

	IfcGuid igu;
	string g64_1 {igu()};
	string h16_1 {igu.B16()};
	string g64_2 {IfcGuid::FromHex(h16_1).Get(IfcGuid::Base64)};
	IfcGuid ogu(igu);
	IfcGuid aga, ogi = ogu;
	aga = ogi;

	string impl {quom + " ---> " + quom};
	cout << quom << g64_1 << impl << h16_1 << impl << g64_2 << quom << endl;
	cout << quom << ogu.B64()  << impl << ogu.B16() << impl << ogu.Get(IfcGuid::Base64) << quom << endl;
	cout << quom << g64_1 << impl << igu.Get(IfcGuid::Base16) << impl << IfcGuid(h16_1, IfcGuid::Base16)() << quom << endl;
	cout << quom << ogi   << impl << hex << ogi << dec << impl << aga << quom << endl;
}
