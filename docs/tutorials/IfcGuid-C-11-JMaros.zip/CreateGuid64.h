// CreateGuid64.h
// ----------------------------------------------------------------------------
// provided "as-is", no warranty, no support is given to the users of this code
// ----------------------------------------------------------------------------
// Janos Maros, March 2015
//
#ifndef _CREATE_GUID64_H_
#define _CREATE_GUID64_H_

#include <string>

// Creation of a 22 characters long string representing a GUID
// Examples
//        IfcGuid   and the corresponding    Hexadecimal GUID
// "0000000000000000000000" <--> "{00000000-0000-0000-0000-000000000000}"
// "0F3WqC2me920S61GG30W40" <--> "{0f0e0d0c-0b0a-0908-0706-050403020100}"
// "0ey9sVfFPDdgqxlMM2IzdH" <--> "{28f09d9f-a4f6-4d9e-ad3b-bd65824bd9d1}"
//

class IfcGuid {
	std::string	m_ifcGuid;
public:
	// types
	enum Base {
		Base64,
		Base16
	};

	// constructors
	IfcGuid ();

	IfcGuid (const IfcGuid &	ig);
	IfcGuid (IfcGuid &&  		ig);

	explicit IfcGuid (const std::string	&	guidStr,
					  Base				 	base = Base64);

	IfcGuid& operator=(const IfcGuid & 	rig);
	IfcGuid& operator=(IfcGuid && 		rva);			  

	//
	// The following accessors and conversion routines
	// will return an empty string on failure.
	//

	const std::string &		operator()()	const;
	const std::string 		B64()			const;
	const std::string 		B16() 			const;
	const std::string 		Get(Base base)	const;

	static std::string	ToHex(const IfcGuid			&ifcGuid);
	static IfcGuid		FromHex(const std::string	&hexGuid);
};

// Serialize the GUID to a stream
template <typename S>
S &		operator << (S &					s,
					 const IfcGuid &		v)
{
	s << v.Get((((s.flags() & s.basefield) == s.hex) ?
				IfcGuid::Base16 : IfcGuid::Base64));
	return	s;
}

#endif
